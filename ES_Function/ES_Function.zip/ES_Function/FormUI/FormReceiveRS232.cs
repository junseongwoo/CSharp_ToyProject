﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ES_Function.FormUI
{
    public partial class FormReceiveRS232 : Form
    {
        public FormReceiveRS232()
        {
            InitializeComponent();
        }

        private void FormReceiveRS232_Load(object sender, EventArgs e)
        {

        }

        private void btnOpenRS232_Click(object sender, EventArgs e)
        {

        }

    }
}
